#include<stdio.h>
#include"Pilha.h"

bool balanceada(const char *sequencia) {
    PILHA *p = pilha_criar();
    if (p == NULL) {
        return false;
    }

    int j = 0;

    while (sequencia[j] != '\0' && sequencia[j] != '\n') {
        char c = sequencia[j];

        if (c == '(' || c == '{' || c == '[') {
            pilha_empilhar(p, c);
        }
        else if (c == ')' || c == '}' || c == ']') {
            if (pilha_vazia(p)) {
                return false;
            }

            char ultimo = pilha_desempilhar(p);

            if ((ultimo == '(' && c != ')') || (ultimo == '{' && c != '}') || (ultimo == '[' && c != ']')) {
                return false;
            }
        }
        ++j;
    }

    bool final = pilha_vazia(p);
    pilha_apagar(p);
    return final;
}
