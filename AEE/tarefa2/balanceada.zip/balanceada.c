#include"Pilha.h"
#include<stdio.h>

bool balanceada(char *sequencia) {
    char atual = sequencia[0];

    int i = 0;
    while (sequencia[i] != '\0') {
        if (sequencia[i] == '(' || sequencia[i] == '{' || sequencia[i] == '[') {
            atual    = sequencia[i];
        } else if (sequencia[i] == ')' || sequencia[i] == '}' || sequencia[i] == ']') {
            if ((atual == '(' && sequencia[i] != ')') || (atual == '{' && sequencia[i] != '}') || (atual == '[' && sequencia[i] != ']')) {
                printf("NAO BALANCEADA\n");
                return false;
            }
        }
        ++i;
    }
    printf("BALANCEADA\n");
    return true;
}