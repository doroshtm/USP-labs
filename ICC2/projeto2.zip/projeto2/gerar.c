#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void gerarordenado(unsigned int *, unsigned int);
void gerarinverso(unsigned int *, unsigned int);
void geraraleatorio(unsigned int *, unsigned int);

int main(void) {
    unsigned int ns[] = {100, 1000, 10000, 100000};
    unsigned int qtd = sizeof(ns)/sizeof(ns[0]);

    gerarordenado(ns, qtd);
    gerarinverso(ns, qtd);
    geraraleatorio(ns, qtd);
}


void gerarordenado(unsigned int *ns, unsigned int quant) {
    for(unsigned int i = 0; i < quant; ++i) {
        unsigned int n = ns[i];
        char filename[64];
        sprintf(filename, "input_%u.txt", n);

        FILE *f = fopen(filename, "w");
        if(!f) {
            perror("fopen");
            exit(1);
        }
        
        fprintf(f, "%u\n", n);

        for(unsigned int j = 1; j <= n; ++j) {
            fprintf(f, "%u\n", sqrt(j)*30+111);
        }
    }
}

void gerarinverso(unsigned int *ns, unsigned int quant) {
    for(unsigned int i = 0; i < quant; ++i) {
        unsigned int n = ns[i];
        char filename[64];
        sprintf(filename, "input_%u.txt", n);

        FILE *f = fopen(filename, "w");
        if(!f) {
            perror("fopen");
            exit(1);
        }

        fprintf(f, "%u\n", n);
        for(unsigned int j = n; j >= 1; --j) {
            fprintf(f, "%u\n", sqrt(j)*30+111);
        }
        fclose(f);
        printf("%s\n", filename);
    }
}

void geraraleatorio(unsigned int *ns, unsigned int quant) {
    for(unsigned int i = 0; i < 5; ++i) {
        for(unsigned int j = 0; j < quant; ++j) {
            unsigned int n = ns[j];
            char filename[64];
            sprintf(filename, "input_%u-%u.txt", n, i);

            FILE *f = fopen(filename, "w");
            if(!f) {
                perror("fopen");
                exit(1);
            }
            fprintf(f, "%u\n", n);
            for(unsigned int k = 0; k < n; ++k) {
                fprintf(f, "%u\n", rand() % (n * 10));
            }
            fclose(f);
            printf("%s\n", filename);
        }
    }
}