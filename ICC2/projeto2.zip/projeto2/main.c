#include<stdio.h>
#include<stdbool.h>

void bubblesort(int *, unsigned int);
void selectionsort(int *, unsigned int);
void insertionsort(int *, unsigned int);
void shellsort(int *, unsigned int);
void quicksort(int *, unsigned int, unsigned int);
void heapsort(int *, unsigned int);
void rearranjar_heap(int *, unsigned int, unsigned int);
void mergesort(int *, unsigned int);
void contagem_menores(int *, unsigned int);
void radixsort(int *, unsigned int, unsigned int);
void copiarvetores(int *, int *, unsigned int);

int main(void) {
    unsigned int n;
    scanf("%u",&n);
    int *v = malloc(n*sizeof(int));
    if(v == NULL) {
        return 1;
    }
    int *v2 = malloc(n*sizeof(int));
    if(v2 == NULL) {
        free(v);
        return 1;
    }
    unsigned int maior = 0;
    for(unsigned int i = 0; i<n; ++i) {
        scanf("%d",&v[i]);
        v2[i] = v[i];
        if(v[i] > v[maior]) {
            maior = i;
        }
    }
    // bubblesort(v2, n);
    // copiarvetores(v, v2, n);
    // selectionsort(v2, n);
    // copiarvetores(v, v2, n);
    // insertionsort(v2, n);
    // copiarvetores(v, v2, n);
    // shellsort(v2, n);
    // copiarvetores(v, v2, n);
    // quicksort(v2, 0, n-1);
    // copiarvetores(v, v2, n);
    // heapsort(v2, n);
    // copiarvetores(v, v2, n);
    // mergesort(v2, n);
    // copiarvetores(v, v2, n);
    // contagem_menores(v2, n, NULL);
    // copiarvetores(v, v2, n);
    // radixsort(v2, n);

}

void bubblesort(int *v, unsigned int n) {
    bool trocou = 1;
    for(unsigned int i = 0; i<n-1 && trocou; ++i) {
        trocou = 0;
        for(unsigned int j = 0; j<n-i-1; ++j) {
            if(v[j]>v[j+1]) {
                int temp = v[j];
                v[j] = v[j+1];
                v[j+1] = temp;
                trocou = 1;
            }
        }
    }
}

void selectionsort(int *v, unsigned int n) {
    for(unsigned int i = 0; i<n-1; ++i) {
        unsigned int min = i;
        for(unsigned int j = i+1; j<n; ++j) {
            if(v[j]<v[min]) {
                min = j;
            }
        }
        if(i!=min) {
            int temp = v[i];
            v[i] = v[min];
            v[min] = temp;
        }
    }
}

void insertionsort(int *v, unsigned int n) {
    for(unsigned int i = 1; i<n; ++i) {
        int temp = v[i];
        unsigned int j;
        for(j = i; j>0 && temp<v[j-1]; --j) {
            v[j] = v[j-1];
        }
        v[j] = temp;
    }
}

void shellsort(int *v, unsigned int n) {
    for(unsigned int h = n/2; h>0; h /= 2) {
        for(unsigned int i = h; i<n; ++i) {
            int temp = v[i];
            unsigned int j;
            while(j>=h && v[j-h] > temp) {
                v[j] = v[j-h];
                j -= h;
            }
            v[j] = temp;
        }
    }
}

void quicksort(int *v, unsigned int esq, unsigned int dir) {
    if(esq>=dir) {
        return;
    }

    unsigned int i = esq, j = dir;
    unsigned int meio = (esq+dir)/2;

    if(v[esq]>v[meio]) {
        int temp = v[esq];
        v[esq] = v[meio];
        v[meio] = temp;
    }
    if(v[esq]>v[dir]) {
        int temp = v[esq];
        v[esq] = v[dir];
        v[dir] = temp;
    }
    if(v[meio]>v[dir]) {
        int temp = v[meio];
        v[meio] = v[dir];
        v[dir] = temp;
    }

    int pivo = v[meio];

    do {
        while(v[i]<pivo) {
            ++i;
        }
        while(v[j]>pivo) {
            --j;
        }
        if(i<=j) {
            if(i<j) {
                int temp = v[i];
                v[i] = v[j];
                v[j] = temp;
            }
            ++i;
            if (j==0) {
                break;
            }
            --j;
        }
    } while(i<j);

    if(j>esq) {
        quicksort(v, esq, j);
    }
    if(i<dir) {
        quicksort(v, i, dir);
    }
}

void copiarvetores(int *origem, int *destino, unsigned int n) {
    for(unsigned int i = 0; i<n; ++i) {
        destino[i] = origem[i];
    }
}

void rearranjar_heap(int *v, unsigned int i, unsigned int n) {
    unsigned int esq=2*i+1, dir=esq+1, maior;
    int temp;

    if(esq<n && v[esq]>v[i]) {
        maior = esq;
    } else {
        maior = i;
    }
    if(dir<n && v[dir]>v[i]) {
        maior = dir;
    }

    if(maior!=i) {
        temp = v[i];
        v[i] = v[maior];
        v[maior] = temp;
        rearranjar_heap(v,maior,n);
    }
}

void heapsort(int *v, unsigned int n) {
    for(unsigned int i = n/2-1; i >= 0; -i) {
        rearranjar_heap(v,i,n);
    }
}

void mergesort(int *v, unsigned int n) {
    int *temp = malloc(n*sizeof(int));
    if(temp == NULL) {
        return;
    }

    int *origem = v;
    int *destino = temp;

    // como vamos duplicando e somando a n, de tamanho unsigned int, vamos usar unsigned long long para evitar possíveis overflows
    for(unsigned long long i = 2; i<n*2; i*=2) {
        for(unsigned long long j = 0; j < n; j += i) {
            unsigned long long meio = j+(i/2), final = j+i;

            if(meio>n) {
                meio = n;
            }
            if(final>n) {
                final = n;
            }

            unsigned long long k=j, l=meio, m=j;
            while(k<meio && l<final) {
                if(v[k] <= v[l]) {
                    temp[m++] = v[k++];
                } else {
                    temp[m++] = v[l++];
                }
            }
            while(k<meio) {
                temp[m++] = v[k++];
            }
            while(l<final) {
                temp[m++] = v[l++];
            }
        }

        int *temp2 = origem;
        origem = destino;
        destino = temp2;

        if(i > n) {
            break;
        }
    }
    if(origem != v) {
        for (unsigned int i = 0; i < n; ++i) {
            v[i] = origem[i];
        }
    }

    free(temp);
}

void contagem_menores(int *v, unsigned int n) {
    int *X = calloc(n,sizeof(int));
    if(X == NULL) {
        return;
    }
    int *B = malloc(n*sizeof(int));
    if(B == NULL) {
        free(X);
        return;
    }

    for(unsigned int i=1; i<n; ++i) {
        for(unsigned int j=i; j>0; --j) {
            if(v[i]<v[j-1]) {
                X[j-1]++;
            } else {
                X[i]++;
            }
        }
    }

    for(int i=0; i<n; ++i) {
        B[X[i]] = v[i];
    }

    for(int i=0; i<n; ++i) {
        v[i] = B[i];
    }
    free(X);
    free(B);
}


void radixsort(int *v, unsigned int n, unsigned int maior) {
    int *v2 = malloc(n*sizeof(int));
    if(v2 == NULL) {
        return;
    }

    int *origem = v, *destino = v2;

    for(unsigned long long i = 1; i <= v[maior]; i *= 10) {
        unsigned int indice[10] = {0};
        // contamos a quantidade de vezes que um dígito aparece entre os números do vetor e incrementamos em indice[dígito]
        for(unsigned int j = 0; j < n; ++j) {
            ++indice[(origem[j]/i % 10)];
        }
        // fazemos tal que indice[dígito] agora representa a quantidade de vezes que o dígito e todos os dígitos menores que ele aparecem
        // isso significa que estamos guardando o índice a seguir do último índice onde um número com esse dígito deveria entrar no vetor
        for(unsigned int j = 0; j < 9; ++j) {
            indice[j+1] += indice[j];
        }
        // guardamos em v2 em ordem decrescente para que possamos garantir que a ordenação será estável, um fator necessário para o radix funcionar corretamente
        for(unsigned int j = n; j > 0; --j) {
            unsigned int digito = (origem[j-1]/i % 10);
            destino[--indice[digito]] = origem[j-1];
        }

        // trocamos destino e origem entre si
        int *temp = origem;
        origem = destino;
        destino = temp;
    }

    if(origem != v) {
        for(unsigned int j = 0; j < n; ++j) {
            v[j] = origem[j];
        }
    }

    free(v2);
}